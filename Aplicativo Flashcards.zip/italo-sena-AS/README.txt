npm init -y
npm install --save-dev electron
npm install electron-reload --save-dev